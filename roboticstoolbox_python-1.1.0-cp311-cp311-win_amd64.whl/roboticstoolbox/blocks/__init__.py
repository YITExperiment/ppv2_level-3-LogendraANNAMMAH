from .arm import *
from .mobile import *
from .uav import *
from .spatial import *

url = "https://petercorke.github.io/robotics-toolbox-python/" + __package__

from roboticstoolbox.backends.PyPlot.PyPlot import PyPlot
from roboticstoolbox.backends.PyPlot.PyPlot2 import PyPlot2

__all__ = [
    'PyPlot',
    'PyPlot2'
]

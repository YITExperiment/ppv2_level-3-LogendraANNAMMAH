/* structs.cpp */

#include "structs.h"
// #include <Eigen/Dense>

extern "C"
{

    // struct ET
    // {
    //     /**********************************************************
    //      *************** kinematic parameters *********************
    //      **********************************************************/
    //     int isjoint;
    //     int isflip;
    //     int jindex;
    //     int axis;
    //     double *T; /* link static transform */
    //     // Eigen::Map<Eigen::Matrix<double, 4, 4, Eigen::RowMajor>> Tm;
    //     double *qlim; /* joint limits */
    //     void (*op)(double *data, double eta);
    // };

} /* extern "C" */
